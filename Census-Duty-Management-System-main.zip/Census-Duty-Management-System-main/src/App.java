import backend.Main;
import frontend.Master;

public class App {
    public static void main(String[] args) {
        Main.run();
        Master.run();
    }
}
