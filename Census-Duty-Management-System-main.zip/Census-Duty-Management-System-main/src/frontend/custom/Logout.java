package frontend.custom;

public interface Logout {
    public abstract void causeLogOut();
}
